//variables

let brushR = 255
let brushG = 255
let brushB = 255
let brushSIZE = 15

let s1r = 255
let s1g = 255
let s1b = 255

let s2r = 0
let s2g = 0
let s2b = 0

let s3r = 255
let s3g = 255
let s3b = 255
let colorImg

let rbr = 255
let obr = 255
let ybr = 255
let gbr = 255
let bbr = 255
let pbr = 255
let wbr = 230



//end of variables

function preload () {
  colorImg = loadImage ('coloring.png');
}

function setup() {
  // put setup code here
  colorMode(RGB,255,255,255);
  createCanvas(500,600);
  background(255,255,255);
  
}

function draw() {
  // put drawing code here

//menu
noStroke();
fill(237,226,211);
rect(0,0,500,120);
//drop shadow
fill(191,164,134);
rect(147,50,336,45,20);
//labels
fill(33,24,20);
//text
textFont('Gegoe');
textStyle(BOLD);
textSize(20);
text('1',160,45);
text('2',195,45);
text('3',235,45);
text('4',265,45);
text('5',295,45);
text('6',325,45);
text('7',355,45);
text('8',385,45);
text('9',415,45);
text('0',445,45);
fill(191,164,134);
textSize(15);
text('current brush',25,30);
textSize(15);
text('hold down left click + desired key', 200,19);
//white area boxes
fill(255,255,255);
rect(150,50,330,40,20); 
rect(30,40,80,60,10);

  frameRate(60);

//key commands
  if (keyIsPressed) {
    if (key == '1') {
      brushSIZE = 5
    s1r = 33
     s1g = 24
     s1b = 20
  
     s2r = 255
     s2g = 255
     s2b = 255
  
     s3r = 255
     s3g = 255
     s3b = 255
    }
    if (key == '2') {
      brushSIZE = 15
  
      s1r = 255
      s1g = 255
      s1b = 255
   
      s2r = 33
      s2g = 24
      s2b = 20
   
      s3r = 255
      s3g = 255
      s3b = 255
    }
    if (key =='3') {
      brushSIZE = 25
  
      s1r = 255
      s1g = 255
      s1b = 255
   
      s2r = 255
      s2g = 255
      s2b = 255
   
      s3r = 33
      s3g = 24
      s3b = 20
    }
    if (key =='4') {
      brushR = 177
      brushG = 71
      brushB = 28
 rbr = 50
 obr = 255
 ybr = 255
 gbr = 255
 bbr = 255
 pbr = 255
 wbr = 230
    }
    if (key =='5') {
      brushR = 217
      brushG = 145
      brushB = 99
 rbr = 255
 obr = 50
 ybr = 255
 gbr = 255
 bbr = 255
 pbr = 255
 wbr = 230
    }
    if (key =='6') {
      brushR = 255
      brushG = 234
      brushB = 191
 rbr = 255
 obr = 255
 ybr = 50
 gbr = 255
 bbr = 255
 pbr = 255
 wbr = 230
    }
    if (key =='7') {
      brushR = 95
      brushG = 148
      brushB = 49
 rbr = 255
 obr = 255
 ybr = 255
 gbr = 50
 bbr = 255
 pbr = 255
 wbr = 230
    }
    if (key =='8') {
      brushR = 118
      brushG = 187
      brushB = 215
 rbr = 255
 obr = 255
 ybr = 255
 gbr = 255
 bbr = 50
 pbr = 255
 wbr = 230
    }
    if (key =='9') {
      brushR = 65
      brushG = 46
      brushB = 81
 rbr = 255
 obr = 255
 ybr = 255
 gbr = 255
 bbr = 255
 pbr = 50
 wbr = 230
    }
    if (key =='0') {
      brushR = 255
      brushG = 255
      brushB = 255
 rbr = 255
 obr = 255
 ybr = 255
 gbr = 255
 bbr = 255
 pbr = 255
 wbr = 50
    }
  }

  
  
  //brush size indicators
    //small
    strokeWeight(1);
  stroke(33,24,20);
  fill(s1r,s1g,s1b);
  ellipse(170,70,5,5);
    //medium - default
  fill(s2r,s2g,s2b);
  ellipse(200,70,15,15);
    //large
  fill(s3r,s3g,s3b);
  ellipse(240,70,25,25);

  //color indicators
  strokeWeight(3);
  //red
  stroke(rbr);
  fill(177,71,28);
  rect(260,58,25,25,5);
  //orange
  stroke(obr);
  fill(217,145,99);
  rect(290,58,25,25,5);
  //yellow
  stroke(ybr);
  fill(255,234,191);
  rect(320,58,25,25,5);
  //green
  stroke(gbr);
  fill(95,148,49);
  rect(350,58,25,25,5);
  //blue
  stroke(bbr);
  fill(118,187,215);
  rect(380,58,25,25,5);
  //purple
  stroke(pbr);
  fill(65,46,81);
  rect(410,58,25,25,5);
  //white
  stroke(wbr);
  fill(255,255,255);
  rect(440,58,25,25,5);

  //current brush indicator
  strokeWeight(1);
  stroke(50);
  fill(brushR,brushG,brushB);
ellipse(70,70,brushSIZE,brushSIZE);


  //constraints for drawing area
  if (mouseY>130) {
  noStroke();
  //strokeWeight(1);
  fill(brushR, brushG, brushB);
  ellipse(mouseX, mouseY, brushSIZE, brushSIZE);
}

image(colorImg, 0,115);

noFill();
strokeWeight(10);
stroke(191,164,134);
rect(2,120,497,479,10);

}

function mousePressed () {
loop ();
}
function mouseReleased () {
  noLoop();
}
